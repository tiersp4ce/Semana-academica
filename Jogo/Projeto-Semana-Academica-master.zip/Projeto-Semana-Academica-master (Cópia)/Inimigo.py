import pygame as pg
import random
from Config import VELOCIDADE_INIMIGO

class Inimigo:
    def __init__(self, posicao, tamanho, velocidade = VELOCIDADE_INIMIGO):
        self.rect = pg.Rect(posicao[0], posicao[1], tamanho, tamanho)
        self.velocidade = velocidade
        self.cor = (255, 0, 0)
        self.hp = 500
        

    def mover(self):
        self.rect.x -= self.velocidade

    def desenhar(self, janela):
        pg.draw.rect(janela, self.cor, self.rect)