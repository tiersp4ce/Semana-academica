import pygame as pg
from Config import COR_VERDE, COR_VERMELHA

class Chao:
    def __init__(self, posicao, largura, altura):
        self.posicao = posicao
        self.largura = largura
        self.altura = altura

    def desenhar(self, janela):
        pg.draw.rect(janela, COR_VERDE, (self.posicao[0], self.posicao[1], self.largura, self.altura))

class Arvore:
    def __init__(self, posicao, largura, altura):
        self.posicao = posicao
        self.largura = largura
        self.altura = altura

    def desenhar(self, janela):
        pg.draw.rect(janela, COR_VERMELHA, (self.posicao[0], self.posicao[1], self.largura, self.altura))
