import pygame as pg
from Config import *
from Ambiente import Chao, Arvore
from Jogador import Jogador
from Pedra import Pedra
from Inimigo import *
import random

def main():
    pg.init()
    janela = pg.display.set_mode((LARGURA, ALTURA))
    pg.display.set_caption("Saruê Defender")

    chao = Chao((0, 300), LARGURA, 80)
    arvore = Arvore((0, 50), 150, ALTURA - 150)
    jogador = Jogador((100, 250))
    pedra = Pedra((128, 0, 128), 30)
    jogador_pos =(50, 250)
    
    inimigos = []
    ultimo_spawn = 0

    executando = True
    clock = pg.time.Clock()
    
    while executando:
        for evento in pg.event.get():
            if evento.type == pg.QUIT:
                executando = False

        mouse_x, mouse_y = pg.mouse.get_pos()
        if pg.mouse.get_pressed()[0]:
            jogador.disparar((mouse_x, mouse_y), pg.time.get_ticks())
        
        jogador.mover_pedras()
        
        # Spawn de inimigos
        tempo_atual = pg.time.get_ticks()
        if tempo_atual - ultimo_spawn > NTERVALO_SPAWN:
            inimigos.append(Inimigo((LARGURA, random.randint(300,340)), 40,0.6))
            ultimo_spawn = tempo_atual

        # Movimentação dos inimigos
        for inimigo in inimigos:
            inimigo.mover()
        
        # Checagem de colisão entre pedras e inimigos
        for pedra_pos in jogador.pedras[:]:
            hp =100
            dano = 150
            pedra_rect = pg.Rect(pedra_pos["pos"], (10, 10))
            for inimigo in inimigos[:]:
                if pedra_rect.colliderect(inimigo.rect):
                    inimigo.hp -= dano
                    jogador.pedras.remove(pedra_pos)
                    if inimigo.hp <= 0:
                        inimigos.remove(inimigo)
        
        # Renderização
        janela.fill(COR_FUNDO)
        chao.desenhar(janela)
        arvore.desenhar(janela)
        for pedra_pos in jogador.pedras:
            pedra.desenhar(janela, pedra_pos["pos"])
        for inimigo in inimigos:
            inimigo.desenhar(janela)
        
        
        pg.draw.rect(janela, (0, 0, 255), (jogador_pos[0],jogador_pos[1], 40, 40))
    

        pg.display.flip()
        clock.tick(60)

    pg.quit()

if __name__ == "__main__":
    main()