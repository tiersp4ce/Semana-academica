import pygame as pg

class Pedra:
    def __init__(self, cor, tamanho):
        self.cor = cor
        self.tamanho = tamanho
        #self.dano = (5)

    def desenhar(self, janela, pos):
        pg.draw.rect(janela, self.cor, (pos[0], pos[1], self.tamanho, self.tamanho))
