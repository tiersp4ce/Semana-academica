# Tamanho da janela
LARGURA = 800
ALTURA = 600

# Cores
COR_FUNDO = (0, 0, 0)
COR_VERDE = (0, 255, 0)
COR_VERMELHA = (255, 0, 0)
COR_ROXA = (128, 0, 128)

# Intervalo de disparo (em milissegundos)
INTERVALO_DISPARO = 300
NTERVALO_SPAWN = 2000

# Velocidades
VELOCIDADE_PEDRA = 15
VELOCIDADE_INIMIGO = 0.5
