import pygame as pg
import math
from Config import VELOCIDADE_PEDRA, INTERVALO_DISPARO

class Jogador:
    def __init__(self, pos_inicial):
        self.pos_inicial = pos_inicial
        self.pedras = []
        self.ultimo_disparo = 0

    def disparar(self, mouse_pos, tempo_atual):
        if tempo_atual - self.ultimo_disparo > INTERVALO_DISPARO:
            dx = mouse_pos[0] - self.pos_inicial[0]
            dy = mouse_pos[1] - self.pos_inicial[1]
            distancia = math.sqrt(dx**2 + dy**2)
            dx /= distancia
            dy /= distancia
            self.pedras.append({"pos": [self.pos_inicial[0], self.pos_inicial[1]], "dx": dx, "dy": dy})
            self.ultimo_disparo = tempo_atual

    def mover_pedras(self):
        for pedra in self.pedras[:]:
            pedra["pos"][0] += pedra["dx"] * VELOCIDADE_PEDRA
            pedra["pos"][1] += pedra["dy"] * VELOCIDADE_PEDRA

            # Se a pedra sair da tela, remove ela da lista
            if pedra["pos"][0] < 0 or pedra["pos"][0] > 800 or pedra["pos"][1] < 0 or pedra["pos"][1] > 600:
                self.pedras.remove(pedra)
